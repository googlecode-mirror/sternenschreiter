-- phpMyAdmin SQL Dump
-- version 3.1.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 05. Mai 2009 um 17:32
-- Server Version: 5.0.41
-- PHP-Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `weltenraum`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ci_sessions`
--

CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `session_user_id` mediumint(9) NOT NULL default '0',
  `session_id` varchar(40) collate utf8_bin NOT NULL default '0',
  `ip_address` varchar(16) collate utf8_bin NOT NULL default '0',
  `user_agent` varchar(150) collate utf8_bin NOT NULL,
  `last_page` varchar(150) collate utf8_bin NOT NULL,
  `last_activity` int(10) unsigned NOT NULL default '0',
  `session_data` text collate utf8_bin,
  PRIMARY KEY  (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Daten für Tabelle `ci_sessions`
--

INSERT INTO `ci_sessions` (`session_user_id`, `session_id`, `ip_address`, `user_agent`, `last_page`, `last_activity`, `session_data`) VALUES
(2, '77138b5e6d2e9995e38e5519cd6579c0', '0.0.0.0', 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.5; de; rv:1.9.0.9) Gecko/2009040820 Firefox/3.0.9', '/menu', 1241193158, 0x613a343a7b733a373a22757365725f6964223b733a313a2232223b733a383a2267726f75705f6964223b733a313a2230223b733a383a22757365726e616d65223b733a363a226672616e7878223b733a393a226c6f676765645f696e223b623a313b7d),
(3, '95eebdb99950070df77ae16eba8b0104', '0.0.0.0', 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.5; de; rv:1.9.0.9) Gecko/2009040820 Firefox/3.0.9', '/menu', 1241193214, 0x613a343a7b733a373a22757365725f6964223b733a313a2233223b733a383a2267726f75705f6964223b733a313a2231223b733a383a22757365726e616d65223b733a353a2261646d696e223b733a393a226c6f676765645f696e223b623a313b7d),
(2, 'e4472744e5ccd14c7f6887b682eaed7b', '0.0.0.0', 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.5; de; rv:1.9.0.9) Gecko/2009040820 Firefox/3.0.9', '/content', 1241194101, 0x613a343a7b733a373a22757365725f6964223b733a313a2232223b733a383a2267726f75705f6964223b733a313a2230223b733a383a22757365726e616d65223b733a363a226672616e7878223b733a393a226c6f676765645f696e223b623a313b7d),
(2, 'e32e38f3da14b57c95acf5628da42301', '0.0.0.0', 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.5; de; rv:1.9.0.9) Gecko/2009040820 Firefox/3.0.9', '/menu', 1241192835, 0x613a343a7b733a373a22757365725f6964223b733a313a2232223b733a383a22757365726e616d65223b733a363a226672616e7878223b733a383a2267726f75705f6964223b733a313a2230223b733a393a226c6f676765645f696e223b623a313b7d),
(2, '90dd48be45669ee18394360ffa7d1c4b', '0.0.0.0', 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.5; de; rv:1.9.0.9) Gecko/2009040820 Firefox/3.0.9', '/content', 1241193108, 0x613a343a7b733a373a22757365725f6964223b733a313a2232223b733a383a2267726f75705f6964223b733a313a2230223b733a383a22757365726e616d65223b733a363a226672616e7878223b733a393a226c6f676765645f696e223b623a313b7d);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cl_groups`
--

CREATE TABLE IF NOT EXISTS `cl_groups` (
  `id` int(11) NOT NULL,
  `name` varchar(50) collate utf8_bin NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Daten für Tabelle `cl_groups`
--

INSERT INTO `cl_groups` (`id`, `name`) VALUES
(0, 'Registered User'),
(1, 'Admin');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cl_group_uri`
--

CREATE TABLE IF NOT EXISTS `cl_group_uri` (
  `group_id` int(11) NOT NULL,
  `request_uri` varchar(40) collate utf8_bin NOT NULL,
  `is_admin` varchar(1) collate utf8_bin NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Daten für Tabelle `cl_group_uri`
--

INSERT INTO `cl_group_uri` (`group_id`, `request_uri`, `is_admin`) VALUES
(0, '/auth', '0');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cl_users`
--

CREATE TABLE IF NOT EXISTS `cl_users` (
  `id` int(11) NOT NULL auto_increment,
  `group_id` int(11) NOT NULL default '0',
  `user_ip` varchar(40) collate utf8_bin NOT NULL,
  `username` varchar(25) collate utf8_bin NOT NULL,
  `username_clean` varchar(25) collate utf8_bin NOT NULL,
  `password` varchar(34) collate utf8_bin NOT NULL,
  `email` varchar(100) collate utf8_bin NOT NULL,
  `banned` varchar(1) collate utf8_bin NOT NULL default '0',
  `ban_reason` varchar(255) collate utf8_bin default NULL,
  `login_attempts` mediumint(1) unsigned NOT NULL default '0',
  `newpass` varchar(34) collate utf8_bin default NULL,
  `newpass_key` varchar(32) collate utf8_bin default NULL,
  `newpass_time` datetime default NULL,
  `active_time` mediumint(8) unsigned NOT NULL default '0',
  `last_visit` datetime NOT NULL default '0000-00-00 00:00:00',
  `created` timestamp NOT NULL default '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=4 ;

--
-- Daten für Tabelle `cl_users`
--

INSERT INTO `cl_users` (`id`, `group_id`, `user_ip`, `username`, `username_clean`, `password`, `email`, `banned`, `ban_reason`, `login_attempts`, `newpass`, `newpass_key`, `newpass_time`, `active_time`, `last_visit`, `created`, `modified`) VALUES
(1, 0, '127.0.0.1', 'Example', 'example', '$1$LV4.2x/.$BvzpsCWupwbHqqFa15uAa/', 'example@your-host.com', '0', NULL, 0, NULL, NULL, NULL, 25, '2008-08-17 14:56:39', '2008-08-17 14:56:01', '2008-08-17 14:56:39'),
(2, 0, '0.0.0.0', 'franxx', 'franxx', 'NoqAUNYu.rn9o', 'franxx@x-0.de', '0', NULL, 0, NULL, NULL, NULL, 16858, '2009-05-01 18:08:21', '2009-03-31 17:43:56', '2009-05-01 18:08:21'),
(3, 1, '0.0.0.0', 'admin', 'admin', 'tUXSRsn8cMUM6', 'admin@x-0.de', '0', NULL, 0, NULL, NULL, NULL, 33240, '2009-05-01 18:06:35', '2009-04-23 15:32:04', '2009-05-01 18:06:35');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cl_user_autologin`
--

CREATE TABLE IF NOT EXISTS `cl_user_autologin` (
  `key_id` char(32) collate utf8_bin NOT NULL,
  `user_id` mediumint(8) NOT NULL default '0',
  `user_agent` varchar(150) collate utf8_bin NOT NULL,
  `last_ip` varchar(40) collate utf8_bin NOT NULL,
  `last_login` int(11) NOT NULL default '0',
  PRIMARY KEY  (`key_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Daten für Tabelle `cl_user_autologin`
--

INSERT INTO `cl_user_autologin` (`key_id`, `user_id`, `user_agent`, `last_ip`, `last_login`) VALUES
('a679e5711781608f79c33008704c13f4', 2, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.5; de; rv:1.9.0.8) Gecko/2009032608 Firefox/3.0.8', '0.0.0.0', 1240077455),
('fbe5667daed932f0ece6f0256847bbae', 2, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.5; de; rv:1.9.0.9) Gecko/2009040820 Firefox/3.0.9', '0.0.0.0', 1241193999);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cl_user_profile`
--

CREATE TABLE IF NOT EXISTS `cl_user_profile` (
  `user_id` int(11) NOT NULL,
  `fullname` varchar(50) collate utf8_bin default NULL,
  `location` varchar(25) collate utf8_bin default NULL,
  `website` varchar(100) collate utf8_bin default NULL,
  `occupation` varchar(50) collate utf8_bin default NULL,
  `introduction` text collate utf8_bin,
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Daten für Tabelle `cl_user_profile`
--

INSERT INTO `cl_user_profile` (`user_id`, `fullname`, `location`, `website`, `occupation`, `introduction`) VALUES
(1, NULL, NULL, NULL, NULL, NULL),
(2, NULL, NULL, NULL, NULL, NULL),
(3, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cl_user_temp`
--

CREATE TABLE IF NOT EXISTS `cl_user_temp` (
  `id` int(11) NOT NULL auto_increment,
  `user_ip` varchar(40) collate utf8_bin NOT NULL,
  `username` varchar(255) collate utf8_bin NOT NULL,
  `username_clean` varchar(255) collate utf8_bin NOT NULL,
  `password` varchar(34) collate utf8_bin NOT NULL,
  `email` varchar(100) collate utf8_bin NOT NULL,
  `activation_key` varchar(50) collate utf8_bin NOT NULL,
  `created` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `cl_user_temp`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `wr_building`
--

CREATE TABLE IF NOT EXISTS `wr_building` (
  `id` int(11) NOT NULL auto_increment,
  `building_id` varchar(64) NOT NULL,
  `building_key` varchar(64) NOT NULL,
  `building_value` varchar(265) NOT NULL,
  `building_status` varchar(1) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `building_id` (`building_id`,`building_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Daten für Tabelle `wr_building`
--

INSERT INTO `wr_building` (`id`, `building_id`, `building_key`, `building_value`, `building_status`) VALUES
(1, '2b29841c-6f79-102c-9ed3-0bb050829a7f', 'BUILDING_NAME', 'Kommandozentrale', '1'),
(2, '2b29841c-6f79-102c-9ed3-0bb050829a7f', 'BUILDING_RES_1', '1200', '1'),
(3, '2b29841c-6f79-102c-9ed3-0bb050829a7f', 'BUILDING_RES_2', '2000', '1'),
(4, '2b29841c-6f79-102c-9ed3-0bb050829a7f', 'BUILDING_RES_3', '1800', '1'),
(5, '8aaf9da8-7ccc-102c-b415-5f94c933a295', 'BUILDING_NAME', 'Generator', '1'),
(6, '8aaf9da8-7ccc-102c-b415-5f94c933a295', 'BUILDING_RES_1', '120', '1'),
(7, '8aaf9da8-7ccc-102c-b415-5f94c933a295', 'BUILDING_RES_2', '200', '1'),
(8, '8aaf9da8-7ccc-102c-b415-5f94c933a295', 'BUILDING_RES_3', '180', '1'),
(9, '2b29841c-6f79-102c-9ed3-0bb050829a7f', 'STARTERLEVEL', '1', '1'),
(10, '8aaf9da8-7ccc-102c-b415-5f94c933a295', 'STARTERLEVEL', '1', '1');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `wr_building_def`
--

CREATE TABLE IF NOT EXISTS `wr_building_def` (
  `id` int(11) NOT NULL auto_increment,
  `building_key` varchar(255) NOT NULL,
  `building_type` int(11) NOT NULL,
  `building_value` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Daten für Tabelle `wr_building_def`
--

INSERT INTO `wr_building_def` (`id`, `building_key`, `building_type`, `building_value`) VALUES
(1, 'BUILDING_NAME', 1, ''),
(2, 'BUILDING_RES_1', 2, '1000'),
(3, 'BUILDING_RES_2', 2, '1000'),
(4, 'BUILDING_RES_3', 2, '1000'),
(5, 'BUILDING_DESCIPTION', 1, 'Beschreibung'),
(6, 'BUILDING_TIME', 2, 'Baudauer'),
(7, 'STARTERLEVEL', 2, '1');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `wr_cron`
--

CREATE TABLE IF NOT EXISTS `wr_cron` (
  `id` int(11) NOT NULL,
  `player_id` varchar(64) NOT NULL,
  `cron_key` varchar(64) NOT NULL,
  `cron_value` varchar(256) NOT NULL,
  `cron_status` varchar(1) NOT NULL,
  `planet_id` varchar(64) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `player_id` (`player_id`,`cron_key`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `wr_cron`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `wr_planets`
--

CREATE TABLE IF NOT EXISTS `wr_planets` (
  `id` int(11) NOT NULL auto_increment,
  `planets_id` varchar(64) NOT NULL,
  `planets_name` varchar(64) NOT NULL,
  `planets_x` int(11) NOT NULL,
  `planets_y` int(11) NOT NULL,
  `planets_z` int(11) NOT NULL,
  `planets_type` int(11) NOT NULL,
  `planets_state` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `player_id` (`planets_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=301 ;

--
-- Daten für Tabelle `wr_planets`
--

INSERT INTO `wr_planets` (`id`, `planets_id`, `planets_name`, `planets_x`, `planets_y`, `planets_z`, `planets_type`, `planets_state`) VALUES
(1, '3f91a5bc-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 70, 96, 1, 1, 1),
(2, '3f91aa26-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 20, 92, 1, 1, 1),
(3, '3f91abc0-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 54, 72, 1, 1, 1),
(4, '3f91ad28-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -69, -73, 1, 1, 1),
(5, '3f91ae9a-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -63, -20, 1, 1, 1),
(6, '3f91b048-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 35, 20, 1, 1, 1),
(7, '3f91b188-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -40, 39, 1, 1, 1),
(8, '3f91b2c8-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 5, -18, 1, 1, 1),
(9, '3f91b408-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -45, 79, 1, 1, 1),
(10, '3f91b548-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -17, -18, 1, 1, 1),
(11, '3f91b692-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -46, 15, 1, 1, 1),
(12, '3f91b7dc-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 13, -74, 1, 1, 1),
(13, '3f91b926-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -20, 41, 1, 1, 1),
(14, '3f91ba70-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 73, -27, 1, 1, 1),
(15, '3f91bbc4-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 94, -18, 1, 1, 1),
(16, '3f91bd0e-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -78, 64, 1, 1, 1),
(17, '3f91be62-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -23, 42, 1, 1, 1),
(18, '3f91c010-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 55, -69, 1, 1, 0),
(19, '3f91c830-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 14, 86, 1, 1, 0),
(20, '3f91c9b6-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -42, 50, 1, 1, 0),
(21, '3f91cb1e-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -34, 92, 1, 1, 0),
(22, '3f91cc7c-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -31, 25, 1, 1, 0),
(23, '3f91cdda-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 30, 74, 1, 1, 0),
(24, '3f91cf42-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -93, 84, 1, 1, 0),
(25, '3f91d0aa-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 52, -11, 1, 1, 0),
(26, '3f91d23a-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -34, -95, 1, 1, 0),
(27, '3f91d3a2-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -96, 79, 1, 1, 0),
(28, '3f91d500-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -70, -17, 1, 1, 0),
(29, '3f91d668-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 19, -97, 1, 1, 0),
(30, '3f91d7d0-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 56, 13, 1, 1, 0),
(31, '3f91d938-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -16, 77, 1, 1, 0),
(32, '3f91dae6-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -24, 61, 1, 1, 0),
(33, '3f91dc26-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 19, -69, 1, 1, 0),
(34, '3f91dd70-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 92, -68, 1, 1, 0),
(35, '3f91deb0-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -83, -51, 1, 1, 0),
(36, '3f91dff0-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 81, -18, 1, 1, 0),
(37, '3f91e13a-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -60, -50, 1, 1, 0),
(38, '3f91e284-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -93, 70, 1, 1, 0),
(39, '3f91e3ce-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -77, -86, 1, 1, 0),
(40, '3f91e522-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 53, 75, 1, 1, 0),
(41, '3f91e676-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 2, -81, 1, 1, 0),
(42, '3f91e7ca-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 79, 6, 1, 1, 0),
(43, '3f91e91e-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 97, -91, 1, 1, 0),
(44, '3f91eac2-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 88, 15, 1, 1, 0),
(45, '3f91ec16-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -89, 43, 1, 1, 0),
(46, '3f91ee28-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -73, -5, 1, 1, 0),
(47, '3f91ef90-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 20, 3, 1, 1, 0),
(48, '3f91f0f8-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -44, -62, 1, 1, 0),
(49, '3f91f256-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 34, -53, 1, 1, 0),
(50, '3f91f3b4-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -30, 51, 1, 1, 0),
(51, '3f91f512-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -4, -49, 1, 1, 0),
(52, '3f91f6a2-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -67, 35, 1, 1, 0),
(53, '3f91f80a-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 0, -61, 1, 1, 0),
(54, '3f91f968-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 5, 23, 1, 1, 0),
(55, '3f91fad0-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -48, -42, 1, 1, 0),
(56, '3f91fc38-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -3, 54, 1, 1, 0),
(57, '3f91fdc8-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -24, -24, 1, 1, 0),
(58, '3f91ff8a-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -40, -28, 1, 1, 0),
(59, '3f9200ca-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -16, -53, 1, 1, 0),
(60, '3f92020a-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 86, -5, 1, 1, 0),
(61, '3f920354-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 90, -87, 1, 1, 0),
(62, '3f920494-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 90, 9, 1, 1, 0),
(63, '3f9205de-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 16, -55, 1, 1, 0),
(64, '3f920728-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 47, -50, 1, 1, 0),
(65, '3f920872-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -8, -84, 1, 1, 0),
(66, '3f9209bc-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 100, 87, 1, 1, 0),
(67, '3f920b06-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -34, -68, 1, 1, 0),
(68, '3f920c5a-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 22, 66, 1, 1, 0),
(69, '3f920dae-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -29, -74, 1, 1, 0),
(70, '3f920f48-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -11, 23, 1, 1, 0),
(71, '3f92109c-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -17, 85, 1, 1, 0),
(72, '3f9211f0-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -23, 58, 1, 1, 0),
(73, '3f92134e-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -40, 36, 1, 1, 0),
(74, '3f9215ba-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -71, 44, 1, 1, 0),
(75, '3f921722-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 83, -85, 1, 1, 0),
(76, '3f921880-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -62, 72, 1, 1, 0),
(77, '3f9219e8-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -72, -72, 1, 1, 0),
(78, '3f921b6e-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -19, 44, 1, 1, 0),
(79, '3f921ce0-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -28, -73, 1, 1, 0),
(80, '3f921e3e-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 94, 63, 1, 1, 0),
(81, '3f921fb0-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -57, 93, 1, 1, 0),
(82, '3f922118-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 49, 9, 1, 1, 0),
(83, '3f922280-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -75, -30, 1, 1, 0),
(84, '3f92242e-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -25, -5, 1, 1, 0),
(85, '3f92256e-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -4, 63, 1, 1, 0),
(86, '3f9226b8-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -82, 78, 1, 1, 0),
(87, '3f9227f8-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 48, -6, 1, 1, 0),
(88, '3f922942-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 35, -93, 1, 1, 0),
(89, '3f922a8c-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -71, 64, 1, 1, 0),
(90, '3f922bcc-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 51, -89, 1, 1, 0),
(91, '3f922d20-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 79, 89, 1, 1, 0),
(92, '3f922e6a-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 83, -93, 1, 1, 0),
(93, '3f922fb4-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -84, -37, 1, 1, 0),
(94, '3f923108-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 51, -13, 1, 1, 0),
(95, '3f923fcc-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -10, 44, 1, 1, 0),
(96, '3f924198-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -50, 32, 1, 1, 0),
(97, '3f9243aa-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 37, 99, 1, 1, 0),
(98, '3f924512-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -59, 61, 1, 1, 0),
(99, '3f924846-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -31, 15, 1, 1, 0),
(100, '3f9249d6-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -44, 64, 1, 1, 0),
(101, '7dec0820-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 54, 2, 1, 1, 0),
(102, '7dec24cc-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -9, 54, 1, 1, 0),
(103, '7dec2ce2-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -91, -31, 1, 1, 0),
(104, '7dec4060-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -10, 25, 1, 1, 0),
(105, '7dec4880-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -20, 86, 1, 1, 0),
(106, '7dec5064-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 81, 22, 1, 1, 0),
(107, '7dec582a-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 37, 67, 1, 1, 0),
(108, '7dec6018-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 98, 66, 1, 1, 0),
(109, '7dec6810-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 18, 41, 1, 1, 0),
(110, '7dec7102-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -73, -72, 1, 1, 0),
(111, '7dec7896-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 15, 87, 1, 1, 0),
(112, '7dec8052-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -61, 70, 1, 1, 0),
(113, '7dec8822-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -89, -62, 1, 1, 0),
(114, '7dec8fc0-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -86, -26, 1, 1, 0),
(115, '7dec9826-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 64, 49, 1, 1, 0),
(116, '7dec9fc4-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -66, 17, 1, 1, 0),
(117, '7deca762-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -50, 25, 1, 1, 0),
(118, '7decaf00-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -30, -41, 1, 1, 0),
(119, '7decb69e-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 94, 59, 1, 1, 0),
(120, '7decbfae-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 84, -26, 1, 1, 0),
(121, '7decc792-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 45, 64, 1, 1, 0),
(122, '7deccf58-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 96, -18, 1, 1, 0),
(123, '7decd8fe-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 31, 93, 1, 1, 0),
(124, '7dece182-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -52, -52, 1, 1, 0),
(125, '7dece998-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 34, -26, 1, 1, 0),
(126, '7decf208-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -25, -52, 1, 1, 0),
(127, '7decf9e2-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -39, 13, 1, 1, 0),
(128, '7ded01a8-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -82, -28, 1, 1, 0),
(129, '7ded0964-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 51, -69, 1, 1, 0),
(130, '7ded112a-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 45, 14, 1, 1, 0),
(131, '7ded18f0-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 79, 78, 1, 1, 0),
(132, '7ded20a2-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -69, -71, 1, 1, 0),
(133, '7ded285e-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 3, 1, 1, 1, 0),
(134, '7ded301a-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -13, -3, 1, 1, 0),
(135, '7ded37d6-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -40, -29, 1, 1, 0),
(136, '7ded403c-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 70, -96, 1, 1, 0),
(137, '7ded47d0-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -66, 65, 1, 1, 0),
(138, '7ded4f64-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -14, 64, 1, 1, 0),
(139, '7ded56f8-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 58, 33, 1, 1, 0),
(140, '7ded5edc-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -89, -9, 1, 1, 0),
(141, '7ded667a-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -93, -15, 1, 1, 0),
(142, '7ded6e18-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 38, -33, 1, 1, 0),
(143, '7ded75ac-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 98, 55, 1, 1, 0),
(144, '7ded7d54-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 38, 49, 1, 1, 0),
(145, '7ded84f2-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 86, -18, 1, 1, 0),
(146, '7ded8c90-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -38, 65, 1, 1, 0),
(147, '7ded942e-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -40, -7, 1, 1, 0),
(148, '7ded9bcc-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 93, 63, 1, 1, 0),
(149, '7deda374-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 93, -20, 1, 1, 0),
(150, '7dedab1c-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -41, -48, 1, 1, 0),
(151, '7dedb2c4-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 50, -71, 1, 1, 0),
(152, '7dedba94-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -44, 83, 1, 1, 0),
(153, '7dedc23c-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 93, 41, 1, 1, 0),
(154, '7dedcaa2-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 47, 51, 1, 1, 0),
(155, '7dedd2c2-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -26, 57, 1, 1, 0),
(156, '7deddace-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -59, -20, 1, 1, 0),
(157, '7dede2b2-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -58, 79, 1, 1, 0),
(158, '7dedea82-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 46, -60, 1, 1, 0),
(159, '7dedf248-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 34, -16, 1, 1, 0),
(160, '7dedfb12-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 88, 19, 1, 1, 0),
(161, '7dee033c-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 65, -51, 1, 1, 0),
(162, '7dee0c7e-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -17, -75, 1, 1, 0),
(163, '7dee141c-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 42, -24, 1, 1, 0),
(164, '7dee1bba-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 87, 34, 1, 1, 0),
(165, '7dee2358-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 56, -55, 1, 1, 0),
(166, '7dee2b00-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 85, 5, 1, 1, 0),
(167, '7dee329e-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -27, -60, 1, 1, 0),
(168, '7dee3a3c-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -12, -34, 1, 1, 0),
(169, '7dee41ee-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 81, -66, 1, 1, 0),
(170, '7dee4996-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -84, -46, 1, 1, 0),
(171, '7dee5148-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 91, -43, 1, 1, 0),
(172, '7dee5b34-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 33, -67, 1, 1, 0),
(173, '7dee6336-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -65, -21, 1, 1, 0),
(174, '7dee6b10-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -28, 68, 1, 1, 0),
(175, '7dee72e0-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 62, -41, 1, 1, 0),
(176, '7dee7aa6-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -13, 27, 1, 1, 0),
(177, '7dee826c-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 8, 70, 1, 1, 0),
(178, '7dee8a32-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 51, -51, 1, 1, 0),
(179, '7dee91ee-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -55, 37, 1, 1, 0),
(180, '7dee99b4-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 82, 100, 1, 1, 0),
(181, '7deea170-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 82, 67, 1, 1, 0),
(182, '7deea936-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 5, -46, 1, 1, 0),
(183, '7deeb0f2-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -94, 92, 1, 1, 0),
(184, '7deeb8c2-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 20, 86, 1, 1, 0),
(185, '7deec07e-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -74, 36, 1, 1, 0),
(186, '7deec844-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -60, -83, 1, 1, 0),
(187, '7deed014-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 92, 73, 1, 1, 0),
(188, '7deed92e-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -51, -74, 1, 1, 0),
(189, '7deee176-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -49, 20, 1, 1, 0),
(190, '7deeeb58-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 94, -87, 1, 1, 0),
(191, '7deef350-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 78, -20, 1, 1, 0),
(192, '7deefb16-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 39, -14, 1, 1, 0),
(193, '7def04ee-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -51, -11, 1, 1, 0),
(194, '7def0cf0-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 34, -6, 1, 1, 0),
(195, '7def14ca-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -74, 16, 1, 1, 0),
(196, '7def1c86-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -6, -93, 1, 1, 0),
(197, '7def244c-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -18, 98, 1, 1, 0),
(198, '7def2bfe-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -39, -12, 1, 1, 0),
(199, '7def34d2-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 90, 80, 1, 1, 0),
(200, '7def3cac-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -26, -85, 1, 1, 0),
(201, '7fdb68c4-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -98, -16, 1, 1, 0),
(202, '7fdb7238-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 85, -84, 1, 1, 0),
(203, '7fdb7a1c-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -58, -13, 1, 1, 0),
(204, '7fdb81ec-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 68, -90, 1, 1, 0),
(205, '7fdb89ee-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 33, 94, 1, 1, 0),
(206, '7fdb9344-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 79, -35, 1, 1, 0),
(207, '7fdb9b00-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 70, -36, 1, 1, 0),
(208, '7fdba2c6-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -24, 78, 1, 1, 0),
(209, '7fdbaa82-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 78, -40, 1, 1, 0),
(210, '7fdbb234-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -73, 74, 1, 1, 0),
(211, '7fdbba22-6f72-102c-9ed3-0bb050829a7f', 'Heimbasis', 0, 13, 1, 1, 1),
(212, '7fdbc1fc-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -35, -89, 1, 1, 0),
(213, '7fdbc9c2-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -96, 68, 1, 1, 0),
(214, '7fdbd246-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -65, -65, 1, 1, 0),
(215, '7fdbd9e4-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 57, -77, 1, 1, 0),
(216, '7fdbe182-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -89, 59, 1, 1, 0),
(217, '7fdbea60-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 7, 96, 1, 1, 0),
(218, '7fdbf24e-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 74, 49, 1, 1, 0),
(219, '7fdbfa00-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -18, 42, 1, 1, 0),
(220, '7fdc019e-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 58, -85, 1, 1, 0),
(221, '7fdc0946-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 35, 37, 1, 1, 0),
(222, '7fdc10f8-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -21, 5, 1, 1, 0),
(223, '7fdc18a0-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 100, 54, 1, 1, 0),
(224, '7fdc20ac-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -17, 78, 1, 1, 0),
(225, '7fdc285e-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -87, 9, 1, 1, 0),
(226, '7fdc302e-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 51, 13, 1, 1, 0),
(227, '7fdc37fe-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -78, -85, 1, 1, 0),
(228, '7fdc3fa6-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 23, -75, 1, 1, 0),
(229, '7fdc4910-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 82, 58, 1, 1, 0),
(230, '7fdc50ea-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -41, 39, 1, 1, 0),
(231, '7fdc58e2-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 80, -30, 1, 1, 0),
(232, '7fdc60f8-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -3, -14, 1, 1, 0),
(233, '7fdc68c8-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -35, -30, 1, 1, 0),
(234, '7fdc70a2-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -65, 47, 1, 1, 0),
(235, '7fdc7854-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -89, 92, 1, 1, 0),
(236, '7fdc802e-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 61, 46, 1, 1, 0),
(237, '7fdc8812-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 28, -61, 1, 1, 0),
(238, '7fdc9032-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -49, 27, 1, 1, 0),
(239, '7fdc97f8-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 93, 33, 1, 1, 0),
(240, '7fdca144-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 5, -94, 1, 1, 0),
(241, '7fdca8ec-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -58, -45, 1, 1, 0),
(242, '7fdcb080-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 18, -37, 1, 1, 0),
(243, '7fdcb828-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -31, -59, 1, 1, 0),
(244, '7fdcbfc6-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -13, -49, 1, 1, 0),
(245, '7fdcc764-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 98, 46, 1, 1, 0),
(246, '7fdccfe8-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 89, 78, 1, 1, 0),
(247, '7fdcd790-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -85, -15, 1, 1, 0),
(248, '7fdcdf42-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -36, -20, 1, 1, 0),
(249, '7fdce6e0-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 55, -2, 1, 1, 0),
(250, '7fdcee88-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -74, 66, 1, 1, 0),
(251, '7fdcf630-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -11, 87, 1, 1, 0),
(252, '7fdcfdce-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 12, -83, 1, 1, 0),
(253, '7fdd0576-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -74, 62, 1, 1, 0),
(254, '7fdd0d28-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 44, -82, 1, 1, 0),
(255, '7fdd14da-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -5, -52, 1, 1, 0),
(256, '7fdd1f5c-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -77, 36, 1, 1, 0),
(257, '7fdd2754-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 2, 40, 1, 1, 0),
(258, '7fdd2f24-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 98, 71, 1, 1, 0),
(259, '7fdd392e-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 80, -15, 1, 1, 0),
(260, '7fdd40fe-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -79, 78, 1, 1, 0),
(261, '7fdd490a-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -70, -90, 1, 1, 0),
(262, '7fdd510c-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 55, -55, 1, 1, 0),
(263, '7fdd58fa-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -5, -82, 1, 1, 0),
(264, '7fdd60f2-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 24, -51, 1, 1, 0),
(265, '7fdd68e0-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 15, 50, 1, 1, 0),
(266, '7fdd71be-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -85, -96, 1, 1, 0),
(267, '7fdd79ac-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 37, 27, 1, 1, 0),
(268, '7fdd814a-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -79, 62, 1, 1, 0),
(269, '7fdd8910-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -11, 64, 1, 1, 0),
(270, '7fdd913a-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 80, 83, 1, 1, 0),
(271, '7fdd991e-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -89, -98, 1, 1, 0),
(272, '7fdda102-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 18, 13, 1, 1, 0),
(273, '7fdda918-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 42, 16, 1, 1, 0),
(274, '7fddb0e8-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -17, 22, 1, 1, 0),
(275, '7fddb8b8-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 100, 4, 1, 1, 0),
(276, '7fddc1f0-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -1, -70, 1, 1, 0),
(277, '7fddc9ca-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 13, -46, 1, 1, 0),
(278, '7fddd1ea-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -26, -93, 1, 1, 0),
(279, '7fddda00-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -29, 98, 1, 1, 0),
(280, '7fdde1f8-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -44, 86, 1, 1, 0),
(281, '7fdde9e6-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 48, -29, 1, 1, 0),
(282, '7fddf1ca-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 90, -16, 1, 1, 0),
(283, '7fddf9a4-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 97, -90, 1, 1, 0),
(284, '7fde0156-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -54, -15, 1, 1, 0),
(285, '7fde093a-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 73, -75, 1, 1, 0),
(286, '7fde1218-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -33, 84, 1, 1, 0),
(287, '7fde19e8-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -73, 85, 1, 1, 0),
(288, '7fde21a4-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -4, 69, 1, 1, 0),
(289, '7fde2992-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 0, 79, 1, 1, 0),
(290, '7fde31ee-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -10, 0, 1, 1, 0),
(291, '7fde39dc-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -17, 89, 1, 1, 0),
(292, '7fde42a6-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 29, 95, 1, 1, 0),
(293, '7fde4a44-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -58, -97, 1, 1, 0),
(294, '7fde5214-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -98, 13, 1, 1, 0),
(295, '7fde59b2-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -99, -42, 1, 1, 0),
(296, '7fde615a-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -1, 49, 1, 1, 0),
(297, '7fde6902-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', 28, -12, 1, 1, 0),
(298, '7fde70a0-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -67, 25, 1, 1, 0),
(299, '7fde7870-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -2, -22, 1, 1, 0),
(300, '7fde811c-6f72-102c-9ed3-0bb050829a7f', 'unbekannt', -90, -29, 1, 1, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `wr_player`
--

CREATE TABLE IF NOT EXISTS `wr_player` (
  `id` int(11) NOT NULL,
  `player_id` varchar(64) NOT NULL,
  `player_key` varchar(64) NOT NULL,
  `player_value` varchar(256) NOT NULL,
  `player_status` varchar(1) NOT NULL,
  KEY `player_id` (`player_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `wr_player`
--

INSERT INTO `wr_player` (`id`, `player_id`, `player_key`, `player_value`, `player_status`) VALUES
(2, '472213d8-6f73-102c-9ed3-0bb050829a7f', 'PLAYER_NAME', 'franxx', '1'),
(2, '472213d8-6f73-102c-9ed3-0bb050829a7f', 'PLAYER_SCORE', '3', '1'),
(2, '472213d8-6f73-102c-9ed3-0bb050829a7f', 'PLAYER_CREDIT', '10000', '1'),
(2, '472213d8-6f73-102c-9ed3-0bb050829a7f', 'PLAYER_ALLY', '', '1'),
(2, '472213d8-6f73-102c-9ed3-0bb050829a7f', 'PLAYER_PLANET', '7fdbba22-6f72-102c-9ed3-0bb050829a7f', '1'),
(3, 'bbd8c40c-8228-102c-aa09-37696ad90380', 'PLAYER_PLANET', '3f91be62-6f72-102c-9ed3-0bb050829a7f', '1'),
(3, 'bbd8c40c-8228-102c-aa09-37696ad90380', 'PLAYER_PLANET', '', '1'),
(3, 'bbd8c40c-8228-102c-aa09-37696ad90380', 'PLAYER_ALLY', '0', '1'),
(3, 'bbd8c40c-8228-102c-aa09-37696ad90380', 'PLAYER_CREDIT', '10000', '1'),
(3, 'bbd8c40c-8228-102c-aa09-37696ad90380', 'PLAYER_SCORE', '0', '1'),
(3, 'bbd8c40c-8228-102c-aa09-37696ad90380', 'PLAYER_NAME', 'admin', '1');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `wr_player_building`
--

CREATE TABLE IF NOT EXISTS `wr_player_building` (
  `id` int(11) NOT NULL auto_increment,
  `player_id` varchar(64) NOT NULL,
  `planet_id` varchar(64) NOT NULL,
  `building_id` varchar(64) NOT NULL,
  `building_level` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `player_id` (`player_id`,`planet_id`,`building_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Daten für Tabelle `wr_player_building`
--

INSERT INTO `wr_player_building` (`id`, `player_id`, `planet_id`, `building_id`, `building_level`) VALUES
(1, '472213d8-6f73-102c-9ed3-0bb050829a7f ', '7fdbba22-6f72-102c-9ed3-0bb050829a7f', '2b29841c-6f79-102c-9ed3-0bb050829a7f', 1),
(6, 'bbd8c40c-8228-102c-aa09-37696ad90380', '3f91be62-6f72-102c-9ed3-0bb050829a7f', '2b29841c-6f79-102c-9ed3-0bb050829a7f', 1),
(7, 'bbd8c40c-8228-102c-aa09-37696ad90380', '3f91be62-6f72-102c-9ed3-0bb050829a7f', '8aaf9da8-7ccc-102c-b415-5f94c933a295', 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `wr_player_planets`
--

CREATE TABLE IF NOT EXISTS `wr_player_planets` (
  `id` int(11) NOT NULL auto_increment,
  `player_id` varchar(64) NOT NULL,
  `planets_id` varchar(64) NOT NULL,
  `planets_status` varchar(1) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `player_id` (`player_id`,`planets_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Daten für Tabelle `wr_player_planets`
--

INSERT INTO `wr_player_planets` (`id`, `player_id`, `planets_id`, `planets_status`) VALUES
(1, '472213d8-6f73-102c-9ed3-0bb050829a7f', '7fdbba22-6f72-102c-9ed3-0bb050829a7f', '1'),
(16, 'bbd8c40c-8228-102c-aa09-37696ad90380', '3f91be62-6f72-102c-9ed3-0bb050829a7f', '1');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `wr_player_science`
--

CREATE TABLE IF NOT EXISTS `wr_player_science` (
  `id` int(11) NOT NULL,
  `player_id` varchar(64) NOT NULL,
  `science_id` varchar(64) NOT NULL,
  `science_level` int(11) NOT NULL,
  `science_cron` varchar(64) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `player_id` (`player_id`,`science_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `wr_player_science`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `wr_science`
--

CREATE TABLE IF NOT EXISTS `wr_science` (
  `id` int(11) NOT NULL auto_increment,
  `science_id` varchar(64) NOT NULL,
  `science_key` varchar(64) NOT NULL,
  `science_value` varchar(256) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `science_id` (`science_id`,`science_key`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `wr_science`
--

